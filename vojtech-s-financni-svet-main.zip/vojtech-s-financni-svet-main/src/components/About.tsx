
import React from 'react';
import { Calculator, PiggyBank, Users } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const About = () => {
  return (
    <section id="about" className="py-20">
      <div className="section-container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-finance-blue mb-4">O mně</h2>
          <div className="w-20 h-1 bg-finance-green mx-auto"></div>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-14 items-center">
          <div className="order-2 lg:order-1">
            <p className="text-lg text-gray-700 mb-8 leading-relaxed">
              Jsem Vojtěch Špatný, finanční specialista s více než 10 lety zkušeností v oboru. 
              Od roku 2013 pracuji pro společnost Benefit Investment, kde se věnuji komplexnímu finančnímu poradenství.
            </p>
            
            <div className="grid md:grid-cols-3 gap-6 mt-10">
              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow bg-white">
                <CardContent className="pt-6 flex flex-col items-center text-center p-6">
                  <div className="bg-finance-green p-4 rounded-full mb-5 shadow-md">
                    <Calculator className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="font-bold text-xl mb-3 text-finance-blue">Zkušenosti</h3>
                  <p className="text-gray-700">
                    Od roku 2013 pracuji jako finanční specialista a pomáhám klientům dosahovat jejich finančních cílů.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow bg-white">
                <CardContent className="pt-6 flex flex-col items-center text-center p-6">
                  <div className="bg-finance-green p-4 rounded-full mb-5 shadow-md">
                    <Users className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="font-bold text-xl mb-3 text-finance-blue">Klientela</h3>
                  <p className="text-gray-700">
                    Důvěřuje mi více než 400 klientů, kterým pomáhám s jejich financemi a dlouhodobým investováním.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow bg-white">
                <CardContent className="pt-6 flex flex-col items-center text-center p-6">
                  <div className="bg-finance-green p-4 rounded-full mb-5 shadow-md">
                    <PiggyBank className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="font-bold text-xl mb-3 text-finance-blue">Přístup</h3>
                  <p className="text-gray-700">
                    Ke každému klientovi přistupuji individuálně a společně hledáme optimální finanční strategii.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
          
          <div className="order-1 lg:order-2 relative flex justify-center items-center">
            {/* Rhombus outline shape behind the image */}
            <div className="absolute h-[500px] w-[400px] bg-finance-blue opacity-5 transform rotate-12 translate-x-8 translate-y-8"></div>
            {/* Rhombus image container */}
            <div className="relative overflow-hidden h-[500px] w-[400px] shadow-xl transform rotate-12">
              {/* Image inside rhombus */}
              <img 
                src="/lovable-uploads/ff925f89-4cc1-4431-9503-d1cd84cb7ebf.png" 
                alt="Vojtěch Špatný v přírodě" 
                className="absolute h-[120%] w-[120%] object-cover transform -rotate-12 -translate-x-6 -translate-y-6"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
