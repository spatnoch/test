
import React from 'react';
import { Separator } from '@/components/ui/separator';
import { MapPin, Phone, Mail } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-finance-blue text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid md:grid-cols-3 gap-12">
          <div>
            <h3 className="text-2xl font-bold text-white mb-6 font-pacifico italic transform -rotate-3">Vojtěch Špatný</h3>
            <p className="text-gray-300 leading-relaxed">
              Finanční specialista s více než 10 lety zkušeností.
              Pracuji pro společnost Benefit Investment od roku 2013.
            </p>
          </div>
          
          <div>
            <h3 className="text-xl font-bold text-white mb-6">Rychlé odkazy</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors hover:underline">Úvod</a></li>
              <li><a href="#about" className="text-gray-300 hover:text-white transition-colors hover:underline">O mně</a></li>
              <li><a href="#services" className="text-gray-300 hover:text-white transition-colors hover:underline">Služby</a></li>
              <li><a href="#contact" className="text-gray-300 hover:text-white transition-colors hover:underline">Kontakt</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold text-white mb-6">Kontakt</h3>
            <div className="space-y-4">
              <div className="flex items-start">
                <Phone className="h-5 w-5 text-finance-green mr-3 mt-0.5" />
                <span>+420 734 265 358</span>
              </div>
              <div className="flex items-start">
                <Mail className="h-5 w-5 text-finance-green mr-3 mt-0.5" />
                <span>spatny@benefitas.cz</span>
              </div>
              <div className="flex items-start">
                <MapPin className="h-5 w-5 text-finance-green mr-3 mt-0.5" />
                <div>
                  <p>Starobranská 44/11</p>
                  <p>787 01 Šumperk</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <Separator className="my-8 bg-gray-700" />
        
        <div className="text-center text-gray-400 text-sm">
          <p>&copy; {currentYear} Vojtěch Špatný. Všechna práva vyhrazena.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
