
import React from 'react';
import { FileChartLine, Coins, WalletCards, HandCoins, HomeIcon, CreditCard } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const Services = () => {
  const services = [
    {
      icon: <FileChartLine className="h-10 w-10 text-finance-green" />,
      title: "Finanční plánování",
      description: "Vytvoření komplexního finančního plánu na míru vašim potřebám a cílům, s důrazem na dlouhodobou prosperitu."
    },
    {
      icon: <Coins className="h-10 w-10 text-finance-green" />,
      title: "Investiční poradenství",
      description: "Profesionální poradenství v oblasti investic s ohledem na váš rizikový profil a dlouhodobé finanční cíle."
    },
    {
      icon: <WalletCards className="h-10 w-10 text-finance-green" />,
      title: "Pojištění",
      description: "Komplexní pojistná řešení pro ochranu vás, vaší rodiny i majetku před neočekávanými událostmi."
    },
    {
      icon: <HandCoins className="h-10 w-10 text-finance-green" />,
      title: "Penze a spoření",
      description: "Příprava na finanční nezávislost v penzi prostřednictvím efektivních spořicích a investičních nástrojů."
    },
    {
      icon: <HomeIcon className="h-10 w-10 text-finance-green" />,
      title: "Hypotéky",
      description: "Komplexní poradenství při výběru nejvýhodnější hypotéky a pomoc s vyřízením celého hypotečního procesu."
    },
    {
      icon: <CreditCard className="h-10 w-10 text-finance-green" />,
      title: "Úvěry",
      description: "Analýza vašich možností a pomoc při získání nejvýhodnějšího úvěru přesně podle vašich potřeb a možností."
    }
  ];

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="section-container">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-finance-blue mb-4">Moje služby</h2>
          <div className="w-20 h-1 bg-finance-green mx-auto mb-6"></div>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            Nabízím komplexní finanční poradenství šité na míru vašim potřebám. 
            Společně najdeme nejvhodnější řešení pro vaši finanční situaci.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mt-10">
          {services.map((service, index) => (
            <Card key={index} className="border-none hover:shadow-xl transition-all duration-300 bg-white hover:-translate-y-2">
              <CardContent className="p-8">
                <div className="mb-6 flex justify-center">
                  <div className="p-4 rounded-full bg-gray-50">
                    {service.icon}
                  </div>
                </div>
                <h3 className="font-bold text-xl mb-4 text-finance-blue text-center">{service.title}</h3>
                <p className="text-gray-700 text-center">{service.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
