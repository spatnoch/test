
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';

const ContactSection = () => {
  return (
    <section id="contact" className="py-20">
      <div className="section-container">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-finance-blue mb-4">Kontaktujte mě</h2>
          <div className="w-20 h-1 bg-finance-green mx-auto mb-6"></div>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            Máte-li jakékoli dotazy nebo máte zájem o konzultaci, neváhejte mě kontaktovat. 
            Rád vám pomůžu s vašimi finančními cíli.
          </p>
        </div>
        
        <div className="grid md:grid-cols-5 gap-10">
          <div className="md:col-span-3 bg-white p-8 rounded-2xl shadow-xl">
            <h3 className="text-2xl font-bold text-finance-blue mb-6">Napište mi</h3>
            <form className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Input 
                    type="text" 
                    placeholder="Jméno a příjmení" 
                    className="border-gray-300 focus:border-finance-green focus:ring focus:ring-finance-green/20 transition-all" 
                  />
                </div>
                <div>
                  <Input 
                    type="email" 
                    placeholder="E-mail" 
                    className="border-gray-300 focus:border-finance-green focus:ring focus:ring-finance-green/20 transition-all" 
                  />
                </div>
              </div>
              <div>
                <Input 
                  type="tel" 
                  placeholder="Telefon" 
                  className="border-gray-300 focus:border-finance-green focus:ring focus:ring-finance-green/20 transition-all" 
                />
              </div>
              <div>
                <Textarea 
                  placeholder="Vaše zpráva" 
                  className="min-h-[180px] border-gray-300 focus:border-finance-green focus:ring focus:ring-finance-green/20 transition-all" 
                />
              </div>
              <Button className="btn-primary w-full py-6 text-lg">
                Odeslat zprávu
              </Button>
            </form>
          </div>
          
          <div className="md:col-span-2 bg-finance-blue p-8 rounded-2xl text-white shadow-xl">
            <h3 className="text-2xl font-bold mb-8 text-white">Kontaktní údaje</h3>
            <div className="space-y-8">
              <div className="flex items-start gap-5">
                <div className="bg-finance-green p-3 rounded-full shrink-0">
                  <Phone className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="font-medium text-white text-lg mb-1">Telefon</p>
                  <p className="text-gray-200 text-lg">+420 734 265 358</p>
                </div>
              </div>
              
              <div className="flex items-start gap-5">
                <div className="bg-finance-green p-3 rounded-full shrink-0">
                  <Mail className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="font-medium text-white text-lg mb-1">Email</p>
                  <p className="text-gray-200 text-lg">spatny@benefitas.cz</p>
                </div>
              </div>
              
              <div className="flex items-start gap-5">
                <div className="bg-finance-green p-3 rounded-full shrink-0">
                  <MapPin className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="font-medium text-white text-lg mb-1">Adresa</p>
                  <p className="text-gray-200">Starobranská 44/11</p>
                  <p className="text-gray-200">787 01 Šumperk</p>
                </div>
              </div>
              
              <div className="flex items-start gap-5">
                <div className="bg-finance-green p-3 rounded-full shrink-0">
                  <Clock className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="font-medium text-white text-lg mb-1">Konzultace</p>
                  <p className="text-gray-200">Pondělí - Pátek: dle dohody</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
