
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Menu, X, Phone } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      setScrolled(offset > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <header className={`w-full bg-white sticky top-0 z-50 transition-all duration-300 ${scrolled ? 'shadow-md py-2' : 'py-4'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex justify-between items-center">
          <div className="flex justify-start lg:w-0 lg:flex-1">
            <a href="#" className="font-pacifico text-2xl md:text-3xl text-finance-blue italic transform -rotate-3 hover:scale-105 transition-transform">
              Vojtěch Špatný
            </a>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <nav className="flex space-x-8">
              <a href="#about" className="text-finance-blue hover:text-finance-green transition-colors font-medium">
                O mně
              </a>
              <a href="#services" className="text-finance-blue hover:text-finance-green transition-colors font-medium">
                Služby
              </a>
              <a href="#contact" className="text-finance-blue hover:text-finance-green transition-colors font-medium">
                Kontakt
              </a>
            </nav>
            
            <a href="tel:+420734265358" className="flex items-center text-finance-blue hover:text-finance-green transition-colors">
              <Phone className="h-4 w-4 mr-2" />
              <span className="font-medium">734 265 358</span>
            </a>
            
            <Button className="btn-primary">
              Sjednat konzultaci
            </Button>
          </div>
          
          <div className="md:hidden">
            <Button 
              variant="ghost" 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="rounded-md p-2 inline-flex items-center justify-center text-finance-blue"
            >
              <span className="sr-only">Otevřít menu</span>
              <Menu className="h-6 w-6" />
            </Button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      <div 
        className={`${isMenuOpen ? 'fixed' : 'hidden'} top-0 inset-x-0 p-2 transition transform origin-top-right md:hidden z-50`}
      >
        <div className="rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 bg-white divide-y-2 divide-gray-50">
          <div className="pt-5 pb-6 px-5">
            <div className="flex items-center justify-between">
              <div>
                <span className="font-pacifico text-2xl text-finance-blue italic transform -rotate-3">
                  Vojtěch Špatný
                </span>
              </div>
              <div className="-mr-2">
                <Button 
                  variant="ghost" 
                  onClick={() => setIsMenuOpen(false)}
                  className="rounded-md p-2 inline-flex items-center justify-center text-finance-blue"
                >
                  <span className="sr-only">Zavřít menu</span>
                  <X className="h-6 w-6" />
                </Button>
              </div>
            </div>
            <div className="mt-6">
              <nav className="grid gap-y-8">
                <a href="#about" onClick={() => setIsMenuOpen(false)} className="text-finance-blue hover:text-finance-green transition-colors font-medium">
                  O mně
                </a>
                <a href="#services" onClick={() => setIsMenuOpen(false)} className="text-finance-blue hover:text-finance-green transition-colors font-medium">
                  Služby
                </a>
                <a href="#contact" onClick={() => setIsMenuOpen(false)} className="text-finance-blue hover:text-finance-green transition-colors font-medium">
                  Kontakt
                </a>
              </nav>
            </div>
          </div>
          <div className="py-6 px-5 space-y-4">
            <a href="tel:+420734265358" className="flex items-center text-finance-blue">
              <Phone className="h-4 w-4 mr-2" />
              <span className="font-medium">734 265 358</span>
            </a>
            <Button className="btn-primary w-full" onClick={() => setIsMenuOpen(false)}>
              Sjednat konzultaci
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
