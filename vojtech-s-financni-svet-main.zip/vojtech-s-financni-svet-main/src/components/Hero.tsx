
import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

const Hero = () => {
  return (
    <div className="relative bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="relative z-10 pb-8 bg-white sm:pb-16 md:pb-20 lg:pb-28 xl:pb-32">
          <div className="section-container pt-10 sm:pt-16 lg:pt-20">
            <div className="lg:grid lg:grid-cols-2 lg:gap-12 items-center">
              <div className="text-center lg:text-left">
                <h1 className="text-4xl tracking-tight font-bold text-finance-blue sm:text-5xl md:text-6xl animate-fade-in">
                  <span className="block">Váš osobní</span>
                  <span className="block text-finance-green mt-2">finanční specialista</span>
                </h1>
                <p className="mt-5 text-base text-gray-700 sm:text-lg md:mt-6 md:text-xl animate-fade-in max-w-lg mx-auto lg:mx-0">
                  Již od roku 2013 pomáhám klientům s jejich finančními cíli.
                  Díky mnohaletým zkušenostem a důvěře více než 400 klientů vám mohu nabídnout profesionální finanční poradenství šité na míru.
                </p>
                <div className="mt-8 sm:flex sm:justify-center lg:justify-start animate-fade-in">
                  <Button className="btn-primary px-8 py-6 text-lg rounded-md shadow-lg flex items-center gap-2">
                    <span>Domluvit konzultaci</span>
                    <ArrowRight className="h-5 w-5" />
                  </Button>
                  <div className="mt-3 sm:mt-0 sm:ml-3">
                    <Button variant="outline" className="btn-outline px-8 py-6 text-lg rounded-md shadow-sm">
                      Více o službách
                    </Button>
                  </div>
                </div>
              </div>
              <div className="mt-12 lg:mt-0 flex justify-center">
                <div className="relative">
                  {/* Rhombus outline shape behind the image */}
                  <div className="absolute h-full w-full bg-finance-green opacity-10 rounded-sm transform -translate-x-8 translate-y-8 rotate-12 scale-110"></div>
                  {/* Rhombus image container */}
                  <div className="relative overflow-hidden h-[500px] w-[400px] shadow-2xl transform rotate-12">
                    {/* Image inside rhombus */}
                    <img 
                      src="/lovable-uploads/31f65917-88ad-4366-8776-95682f011d42.png" 
                      alt="Vojtěch Špatný - finanční specialista"
                      className="absolute h-[120%] w-[120%] object-cover transform -rotate-12 -translate-x-4 -translate-y-4"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
